# HDI Analysis Assignment
Student: MD Seraj (2516663)
Course: 5CS037
Date: January 10, 2026

Complete analysis of HDI dataset.
All 4 problems completed.